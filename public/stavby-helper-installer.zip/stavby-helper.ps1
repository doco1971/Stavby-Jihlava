# stavby-helper.ps1
# Lokalni HTTP helper pro otevirani slozek z aplikace Stavby
# Bezi na pozadi na http://localhost:3210
# Spustit: powershell -ExecutionPolicy Bypass -File stavby-helper.ps1

$port = 3210
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()

Write-Host "Stavby Helper bezi na http://localhost:$port"
Write-Host "Stisknete Ctrl+C pro zastaveni"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        # CORS hlavicky - dulezite pro web
        $response.Headers.Add("Access-Control-Allow-Origin", "*")
        $response.Headers.Add("Access-Control-Allow-Methods", "GET, OPTIONS")

        $url = $request.Url
        $path_local = $url.AbsolutePath

        if ($path_local -eq "/ping") {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } elseif ($path_local -eq "/open") {
            $query = [System.Web.HttpUtility]::ParseQueryString($url.Query)
            $folderPath = $query["path"]

            if ($folderPath -and $folderPath -ne "") {
                try {
                    Start-Process "explorer.exe" -ArgumentList $folderPath
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes("OK")
                    $response.StatusCode = 200
                } catch {
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes("ERROR: $_")
                    $response.StatusCode = 500
                }
            } else {
                $buffer = [System.Text.Encoding]::UTF8.GetBytes("ERROR: prazdna cesta")
                $response.StatusCode = 400
            }
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

        } else {
            $buffer = [System.Text.Encoding]::UTF8.GetBytes("Stavby Helper OK")
            $response.StatusCode = 200
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }

        $response.OutputStream.Close()

    } catch {
        # Ignoruj chyby pri zavirani
    }
}
